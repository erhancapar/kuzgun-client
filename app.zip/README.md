# Kuzgun - End-to-End Encrypted Communication App

**Kuzgun** is a privacy-focused, end-to-end encrypted communication app built with Electron.
