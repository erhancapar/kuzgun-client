// main.js
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let win;
let isDay = true; // Varsayılan tema durumu

function createWindow() {
  win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true, // Renderer süreçte Node.js entegrasyonu
      contextIsolation: false, // Gerekiyorsa bunu da false yapın
    },
  });

  win.loadFile('public/index.html');

  // Pencere yüklendiğinde tema durumunu gönder
  win.webContents.on('did-finish-load', () => {
    win.webContents.send('theme-updated', isDay);
  });
}

// Tema durumunu dinle ve güncelle
ipcMain.on('toggle-theme', (event) => {
  isDay = !isDay;
  // Tüm renderer süreçlere yeni tema durumunu gönder
  win.webContents.send('theme-updated', isDay);
});

// Navigasyon işlemleri
ipcMain.on('navigate', (event, arg) => {
  if (arg === 'login') {
    win.loadFile('public/login.html');
  } else if (arg === 'index') {
    win.loadFile('public/index.html');
  } else if (arg === 'forgot-password') {
    win.loadFile('public/forgot-password.html');
  }

  // Sayfa yüklendikten sonra tema durumunu gönder
  win.webContents.once('did-finish-load', () => {
    win.webContents.send('theme-updated', isDay);
  });
});

app.whenReady().then(createWindow);

// Uygulama tüm pencereler kapandığında çıkış yap
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Uygulama etkin olduğunda (macOS için)
app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

